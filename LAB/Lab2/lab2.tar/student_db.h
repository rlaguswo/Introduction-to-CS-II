#ifndef STUDENT_DB_H
#define STUDENT_DB_H

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>

using namespace std;

struct student{
	int id;
	string first_name;
	string last_name;
	string major;
};
#endif 

student* create_student_db(int a);

void swap(int& a,int& b); 

void populate_student_db_info(student* s,int a,ifstream& f);

void delete_student_db_info(student** s, int a);

void print_id(student* s,int a,ofstream& f);

void sort_by_id(student* s,int a,ofstream& f);

void print_last_name(student* s,int a,ofstream& f);

void sort_by_lastname(student* s,int a,ofstream& f);

void print_major(student* s,int a,ofstream& f);

void sort_unique_major(student* s,int a,ofstream& f);
