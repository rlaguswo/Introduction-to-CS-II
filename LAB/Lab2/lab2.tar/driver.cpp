#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>

#include "student_db.h"

int main(int argc,const char** argv){
	ifstream file;
	ofstream file2;
	string str;
	file.open("input.txt");
	file2.open("output.txt");
	if(!file.is_open()|| !file2.is_open()){
		cout << "Error opening the file to read!" << endl;
		return 1;
		}
	getline(file,str);


	int num_of_students = atoi(str.c_str());	
	
	student* s = create_student_db(num_of_students);
	
	populate_student_db_info(s,num_of_students,file);
	
	sort_by_id(s,num_of_students,file2);
	
	sort_by_lastname(s,num_of_students,file2);
	
	sort_unique_major(s,num_of_students,file2);
	
	delete_student_db_info(&s,num_of_students);
	
	file.close();
	file2.close();

return 0;
}
