#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>

#include "student_db.h"


using namespace std;

student* create_student_db(int a){
	student* s = new student[a];
	return s;

}

void swap(int& a,int& b){
	int tmp = a;
	a = b;
	b = tmp;

}


void populate_student_db_info(student* s,int a,ifstream& f){
	for(int i = 0;i < a;i++){
		f >> s[i].id >> s[i].first_name >> s[i].last_name >> s[i].major;
	}

}

void delete_student_db_info(student** s,int a){
//	for(int i = 0;i < a;i++){
//		delete [] (*s)[i];
//		(*s)[i] = NULL;
//	}
	delete [] *s;
	*s = NULL;

}


void print_id(student* s,int a,ofstream& f){
	f<< "<ID>" << endl;
	for(int i = 0;i < a;i++){
		f << s[i].id << " " << s[i].first_name << " " << s[i].last_name << " ";
		f << endl;
	}
	f << endl;

}


void sort_by_id(student* s,int a,ofstream& f){
	for(int i = 1;i < a;i++){
		for(int j = 0;j < a-1;j++){
			if(s[j].id > s[j+1].id){
				swap(s[j].id,s[j+1].id);
			}
		}
	}
	print_id(s,a,f);
}

void print_last_name(student*s ,int a,ofstream& f){
	f << "<LAST NAME>" << endl;
	for(int i = 0;i < a;i++){
		f << s[i].last_name << " ";
		f << endl;
	}
	f << endl;
}

void sort_by_lastname(student* s,int a,ofstream& f){
	for(int i = 1;i < a;i++){
		for(int j = 0;j < a-1;j++){
			if(s[j].last_name > s[j+1].last_name)
				swap(s[j].last_name,s[j+1].last_name);
		}
	}
	print_last_name(s,a,f);
}

void print_major(int a,ofstream& f){
	f << "<THE NUMBER OF UNIQUE MAJOR>" << endl;
	f << a << endl;
}

void sort_unique_major(student* s,int a,ofstream& f){
	for(int i = 1;i < a;i++){
		for(int j = 0;j < a-1;j++){
			if(s[j].major < s[j+1].major)
				swap(s[j],s[j+1]);
		}
	}
		int counter = 1;

		for (int i = 0; i < a-1; i ++)
			if (s[i].major != s[i+1].major)
				counter ++;

	print_major(counter,f);
}
